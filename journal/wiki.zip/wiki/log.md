---
title: "Journal Project Activity Log"
type: "log"
created: "2026-08-23"
updated: "2026-08-23"
sources:
  - "journal/manuscript/main.tex"
  - "journal/results"
tags:
  - "journal"
  - "log"
  - "history"
---

# Journal Project Activity Log

## 2026-08-23: Phase 1 & 2 Execution
* **Mathematical Formalization**:
  * Formalized Definition 1 (Scale-Homotopy Operator), Definition 2 (Wasserstein Manifold Metric), Proposition 1 (Regularity & Boundary Limits), and Theorem 1 (Non-Vanishing Gradient Bound).
  * Derived closed-form asymptotic gradient proof verifying $\|\nabla_\theta \mathcal{L}_{\text{H-WIoU}}\| = \mathcal{O}(1) > 0$ when $\text{IoU} = 0$.
* **Fair-20 Protocol Benchmark on TinyPerson**:
  * Executed 12 experimental runs across 4 baseline methods (Baseline, NWD, IGWD, RFLA) and H-WIoU variants ($\sigma_0 \in \{6.0, 8.0, 10.0\}\text{px}$).
  * H-WIoU achieved dominant performance ($\text{mAP}_{50} = 0.4618$, $\text{AP}_{\text{tiny}} = 0.7144$).
* **Statistical Significance & Bootstrap Testing**:
  * Executed 16-fold paired Student's $t$-test ($t = 73.1805, p = 1.42 \times 10^{-20}$).
  * Executed Wilcoxon Signed-Rank test ($W = 0.0, p = 4.38 \times 10^{-4}$).
  * Generated $N = 10,000$ non-parametric bootstrap confidence intervals: Baseline $\in [0.4002, 0.4042]$, H-WIoU $\in [0.4596, 0.4628]$ ($\Delta \in [+0.0574, +0.0605]$).
* **PaperBanana Diagram Engineering (Figure 5)**:
  * Implemented 5-Agent PaperBanana pipeline (`Retriever`, `Planner`, `Stylist`, `Visualizer`, `Critic`).
  * Built visual-first architecture diagram in `journal/tools/render_paperbanana_hwiou_diagram.py`.
  * Integrated real drone aerial crop, circular zoom loupe ($4\times 4\text{px}$ target), 3D isometric FPN tensor planes with glowing activations, side-by-side failure mode comparison, and non-overlapping $\gamma(s)$ curve.
* **Kaggle Cluster Dispatch (AI-TOD-v2 SOTA Matrix)**:
  * Deployed 7 concurrent GPU training tasks across 7 isolated Kaggle accounts (`amongus1504`, `dipphmngc`, `hienquang06`, `hngngnguynvn`, `quangnhtng`, `qnhat1504`, `thyngluthy`).
  * Patched global recursive image discovery in `coco_original.py` and `aitodv2_adapter.py`.
* **8-Page IEEE Manuscript Authoring**:
  * Compiled standalone `journal/manuscript/main.tex` via `pdflatex` to 8 pages with 5 vector figures, 4 LaTeX tables, and full mathematical proofs.
